<?php
namespace Arpo\CustomFields\Setup;


use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Eav\Api\AttributeManagementInterface;
use Magento\Catalog\Model\Config;

class UpgradeData implements UpgradeDataInterface
{
    private $eavSetupFactory;
    private $attributeManagement;
    private $config;

    public function __construct(
        EavSetupFactory $eavSetupFactory,
        AttributeManagementInterface $attributeManagement,
        Config $config
    )
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->attributeManagement = $attributeManagement;
        $this->config = $config;
    }

    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        if (version_compare($context->getVersion(), '1.0.0', '<')) {
            $this->addTextAresAttribute($eavSetup, 'second_product_name_field', 'Product Short Description');
        }

        if (version_compare($context->getVersion(), '1.1.1', '<')) {
            $this->addTextAresAttribute($eavSetup, 'howtocook', 'How to cook');
        }

        if (version_compare($context->getVersion(), '1.1.3', '<')) {
            $this->addYesNoAttribute($eavSetup, 'mit20amino', 'Mit 20 Aminosäuren');
            $this->addYesNoAttribute($eavSetup, 'protein', 'Protein');
            $this->addYesNoAttribute($eavSetup, 'vegan', 'Vegan');
            $this->addYesNoAttribute($eavSetup, 'ballaststoffe', 'Ballaststoffe');
        }
    }

    /**
     * @param $eavSetup
     */
    public function addTextAresAttribute($eavSetup, $attributeCode, $attributeLabel, $attributeSetGroup = 'general')
    {
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            $attributeCode,
            [
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => $attributeLabel,
                'input' => 'textarea',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'sort_order' => 3,
                'is_html_allowed_on_front' => true,
                'apply_to' => ''
            ]
        );

        $this->assignToAttributeSet($eavSetup, $attributeCode, $attributeSetGroup);
    }

    /**
     * @param $eavSetup
     */
    public function addYesNoAttribute($eavSetup, $attributeCode, $attributeLabel, $attributeSetGroup = 'general')
    {
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            $attributeCode,
            [
                'type' => 'int',
                'label' => $attributeLabel,
                'input' => 'boolean',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_STORE,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '0',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
            ]
        );

        $this->assignToAttributeSet($eavSetup, $attributeCode, $attributeSetGroup);
    }

    /**
     * @param $eavSetup
     * @param $attributeCode
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function assignToAttributeSet($eavSetup, $attributeCode, $attributeSetGroup = 'general', $attributeSetIds = array())
    {
        $attributeSetIds = !empty($attributeSetIds) ? $attributeSetIds : $eavSetup->getAllAttributeSetIds(\Magento\Catalog\Model\Product::ENTITY);
        foreach ($attributeSetIds as $attributeSetId) {
            $groupId = $this->config->getAttributeGroupId($attributeSetId, $attributeSetGroup);
            if (!empty($groupId)) {
                $this->attributeManagement->assign(
                    \Magento\Catalog\Model\Product::ENTITY,
                    $attributeSetId,
                    $groupId,
                    $attributeCode,
                    130
                );
            }
        }
    }
}